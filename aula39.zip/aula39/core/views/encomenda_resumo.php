<div class="container espaco-fundo">
    <div class="row">
        <div class="col-12">
            <h2>Resumo da sua encomenda</h2>
            <div class="row">
                  <table class='table'>
                    <thead>
                      <tr>
                        <th>Produto</th>
                        <th class="text-center">Quantidade</th>
                        <th class="text-end">Valor Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                          $index = 0;
                          $total_rows = count($carrinho);
                      ?>
                      <?php foreach($carrinho as $produto): ?>
                      <?php if($index < $total_rows-1): ?>
                        <tr>
                          <td class="align-middle"><?= $produto['titulo'] ?></td>
                          <td class="align-middle text-center"><?= $produto['quantidade'] ?></td>
                          <td class="text-end align-middle"><?= 'R$ '.number_format($produto['preco'], 2, ',', '.') ?></td>
                          <td class="text-center align-middle">
                        </tr>
                        <?php else: ?>
                          <td></td>
                          <td class="text-end"><h4>Total:</h4></td>
                          <td class="text-end align-middle"><h4><?= 'R$ '.number_format($produto, 2, ',', '.'); ?></h4></td>
                        <?php endif; ?>
                        <?php $index ++; ?>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                  <div>
                      <?php 
                        print_r($cliente);
                      ?>
                  </div>
                  <div class="row">
                  <div class="col">
                    Cancelar
                </div>
                <div class="col text-end">
                    Escolher metdo de pagamento
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
