<?php 

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;

class Admin
{
    // ====================================================================
    public function index()
    {
        echo "Admin index";
    }
    
    // ====================================================================
    public function lista_clientes()
    {
        echo "lista de clientes";
    }
}

?>
