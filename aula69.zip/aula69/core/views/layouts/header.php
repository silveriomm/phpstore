<?php

use core\classes\Store;

// calcula o número de produtos no carrinho
$total_produtos = 0;
if(isset($_SESSION['carrinho']))
{
  foreach($_SESSION['carrinho'] as $quantidade)
  {
    $total_produtos += $quantidade;
  }
}

?>

<div class="container-fluid navegacao">
    <div class="row">
    <div class="col-6 p-3">
        <a href="?a=inicio" class="logo">
            <h4><?=  APP_NAME ?></h4>
        </a>
    </div>
        <div class="col-6 text-end p-3">
            <a href="?a=inicio" class="nav-item">
                <i class="fas fa-rocket"></i> Início
            </a>
            <a href="?a=loja" class="nav-item">
                <i class="fas fa-building"></i> Loja
            </a>
            <!-- verifica se existe cliente na sessão -->
            <?php if(Store::clienteLogado()): ?>
                <a href="?a=perfil" class="nav-item">
                    <?= $_SESSION['usuario']; ?> <i class="fas fa-user"></i>
                </a>
                <a href="?a=logout" class="nav-item">
                    <i class="fas fa-door-open"></i> Sair
                </a>
            <?php else: ?>
                <a href="?a=login" class="nav-item">
                    <i class="fas fa-user-lock"></i> Entrar
                </a>
                <a href="?a=novo_cliente" class="nav-item">
                <i class="fas fa-file-invoice"></i> Criar conta
                </a>
            <?php endif;?>

            <a href="?a=carrinho" class="nav-item">
                <i class="fas fa-shopping-cart"></i> Carrinho
            </a>
            <span class="badge bg-warning" id="carrinho"><?= $total_produtos == 0 ? '' : $total_produtos ?></span>
        </div>
    </div>
</div>
