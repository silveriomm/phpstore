<div class="container espaco-fundo">
    <div class="row">
        <div class="col-12">
            <h2>Resumo da sua encomenda</h2>
            <div class="row">
                  <table class='table'>
                    <thead>
                      <tr>
                        <th>Produto</th>
                        <th class="text-center">Quantidade</th>
                        <th class="text-end">Valor Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                          $index = 0;
                          $total_rows = count($carrinho);
                      ?>
                      <?php foreach($carrinho as $produto): ?>
                      <?php if($index < $total_rows-1): ?>
                        <tr>
                          <td class="align-middle"><?= $produto['titulo'] ?></td>
                          <td class="align-middle text-center"><?= $produto['quantidade'] ?></td>
                          <td class="text-end align-middle"><?= 'R$ '.number_format($produto['preco'], 2, ',', '.') ?></td>
                          <td class="text-center align-middle">
                        </tr>
                        <?php else: ?>
                          <td></td>
                          <td class="text-end"><h4>Total:</h4></td>
                          <td class="text-end align-middle"><h4><?= 'R$ '.number_format($produto, 2, ',', '.'); ?></h4></td>
                        <?php endif; ?>
                        <?php $index ++; ?>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                  <div>
                    <!-- Dados do cliente -->
                    <h5 class="bg-dark text-white p-2">Dados do cliente</h5>
                    <div class="row">
                      <div class="col">
                        <p>Nome: <strong><?= $cliente->nome_completo ?></strong></p>
                        <p>Endereço: <strong><?= $cliente->morada ?></strong></p>
                        <p>Cidade: <strong><?= $cliente->cidade ?></strong></p>
                      </div>
                      <div class="col">
                        <p>Email: <strong><?= $cliente->email ?></strong></p>
                    <p>Telefone: <strong><?= $cliente->telefone ?></strong></p>
                      </div>
                    </div>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" onchange="usar_morada_alternativa()" type="checkbox" name="check_morada_alternativa" id="check_morada_alternativa">
                    <label class="form-check-label" for="check_morada_alternativa"><b>Alterar endereço de envio.</b></label>
                  </div>
                  <!-- Endereço -->
                  <div id="morada_alternativa" style="display: none;">
                      Morada alternativa
                  </div>
                  <!-- Fim de endereço -->
                  <div class="row mt-4">
                  <div class="col">
                    Cancelar
                </div>
                <div class="col text-end">
                    Escolher metdo de pagamento
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
