<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h1>Carrinho</h1>
            <a href="?a=limpar_carrinho" class="btn btn-sm btn-info">Limpar carrinho</a>
            <div class="row">
                <?php if($carrinho == null): ?>
                    <p>Carrinho vazio</p>
                <?php else: ?>
                    <p>Carrinho...</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <a href="?a=loja" class="btn btn-primary">Loja</a>
</div>
