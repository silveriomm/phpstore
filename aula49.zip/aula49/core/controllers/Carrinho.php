<?php

namespace core\controllers;

use core\classes\Store;
use core\classes\EnviarEmail;
use core\classes\Database;
use core\models\Clientes;
use core\models\Produtos;
use core\models\Encomendas;


class Carrinho
{

    // ====================================================
    public function adicionar_carrinho()
    {
      // busca o id do produto
      if(!isset($_GET['id_produto']))
      {
        echo isset($_SESSION['carrinho']) ? count($_SESSION['carrinho']) : '';
        return;
      }

      // define o id do produto
      $id_produto = $_GET['id_produto'];

      $produtos = new Produtos;
      $resultados = $produtos->verificar_stock_produto($id_produto);

      if(!$resultados)
      {
        echo isset($_SESSION['carrinho']) ? count($_SESSION['carrinho']) : '';
        return;
      }

      // adiciona a variável a sessão
      $carrinho = [];

      if(isset($_SESSION['carrinho']))
      {
        $carrinho = $_SESSION['carrinho'];
      }

      // adiciona o produto ao carrinho
      if(key_exists($id_produto, $carrinho))
      {
        // já existe o produto, acrescenta mais
        $carrinho[$id_produto] ++;
      }
      else
      {
        // adiciona novo produto
        $carrinho[$id_produto] = 1;
      }

      $_SESSION['carrinho'] = $carrinho;

      $total_produtos = 0;

      foreach($carrinho as $quantidade)
      {
        $total_produtos += $quantidade;
      }

      echo $total_produtos;
    }

    // ====================================================
    public function remover_produto_carrinho()
    {
        // busca o id do produto
        $id_produto = $_GET['id_produto'];
        // busca o carrinho na sessão
        $carrinho = $_SESSION['carrinho'];
        // remove o produto da carrinho
        unset($carrinho[$id_produto]);
        // recarrega a sessão
        $_SESSION['carrinho'] = $carrinho;
        
        // recarrega a página
        $this->carrinho();
    }

    // ====================================================
    public function limpar_carrinho()
    {
      // limpa o carrinho de todos os produtos
      unset($_SESSION['carrinho']);

      // reinicia a página do carrinho
      $this->carrinho();
    }

    // ====================================================
    public function carrinho()
    {
        // verifica se existe carrinho
        if(!isset($_SESSION['carrinho']) || count($_SESSION['carrinho']) == 0)
        {
            $dados = [
                'carrinho' => null
            ];
        }
        else
        {
           $ids = [];

           foreach($_SESSION['carrinho'] as $id_produto => $quantidade)
           {
                array_push($ids, $id_produto);
           }

           $ids = implode(",", $ids);
           $produtos = new Produtos();
           $resultados = $produtos->buscar_produtos_por_ids($ids);

          $dados_tmp = [];

          foreach($_SESSION['carrinho'] as $id_produto => $quantidade_carrinho)
          {
            // buscar imagem do produto
            foreach($resultados as $produto)
            {
              if($produto->id_produto == $id_produto)
              {
                $id_produto = $produto->id_produto;
                $imagem = $produto->imagem;
                $titulo = $produto->nome_produto;
                $quantidade = $quantidade_carrinho;
                $preco = $produto->preco * $quantidade;

                // colocar os dados na coleção
                array_push($dados_tmp, [
                'id_produto' => $id_produto,
                'imagem' => $imagem,
                'titulo' => $titulo,
                'quantidade' => $quantidade,
                'preco' => $preco
              ]);
              break;
              }
            }
          }

          // calcular o total
          $total_encomenda = 0;
          foreach($dados_tmp as $item)
          {
            $total_encomenda += $item['preco'];
          }

          array_push($dados_tmp, $total_encomenda);

          // colocoar o preço total na sessão
          $_SESSION['total_encomenda'] = $total_encomenda;

           $dados = [
              'carrinho' => $dados_tmp
           ];
        }

         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'carrinho',
            'layouts/footer',
            'layouts/html_footer',
        ], $dados);
    }

    // ====================================================
    public function finalizar_encomenda()
    {
        // verifica se o cliente está logado
        if(!isset($_SESSION['cliente']))
        {
            // coloca na sessão um referrer temporário
            $_SESSION['tmp_carrinho'] = true;

            // redireciona para o login
            Store::redirect('login');
        }
        else
        {
          Store::redirect('finalizar_encomenda_resumo');
        }
    }
    
    // ====================================================
    public function finalizar_encomenda_resumo()
    {
      // verifica se existe cliente logado
      if(!isset($_SESSION['cliente']))
      {
        Store::redirect('inicio');
      }

      $ids = [];

      foreach($_SESSION['carrinho'] as $id_produto => $quantidade)
      {
           array_push($ids, $id_produto);
      }
      
      // Carrinho -----------------------------------------
      
      $ids = implode(",", $ids);
      $produtos = new Produtos();
      $resultados = $produtos->buscar_produtos_por_ids($ids);

     $dados_tmp = [];

     foreach($_SESSION['carrinho'] as $id_produto => $quantidade_carrinho)
     {
       // buscar imagem do produto
       foreach($resultados as $produto)
       {
         if($produto->id_produto == $id_produto)
         {
           $id_produto = $produto->id_produto;
           $imagem = $produto->imagem;
           $titulo = $produto->nome_produto;
           $quantidade = $quantidade_carrinho;
           $preco = $produto->preco * $quantidade;

           // colocar os dados na coleção
           array_push($dados_tmp, [
           'id_produto' => $id_produto,
           'imagem' => $imagem,
           'titulo' => $titulo,
           'quantidade' => $quantidade,
           'preco' => $preco
         ]);
         break;
         }
       }
     }

     // calcular o total
     $total_encomenda = 0;
     foreach($dados_tmp as $item)
     {
       $total_encomenda += $item['preco'];
     }

     array_push($dados_tmp, $total_encomenda);

     // preparar os dados da view
     $dados = [];
    $dados['carrinho'] = $dados_tmp;

    // Cliente --------------------------------------------

    // buscar informação do cliente
    $cliente = new Clientes();
    $dados_cliente = $cliente->buscar_dados_cliente($_SESSION['cliente']);
    $dados['cliente'] = $dados_cliente;

    // -------------------------------------------------
    // gerar o código da encomenda
    if(!isset($_SESSION['codigo_encomenda']))
    {
        $codigo_encomenda = Store::gerar_codigo_encomenda();
        $_SESSION['codigo_encomenda'] = $codigo_encomenda;
    }

        Store::Layout([
          'layouts/html_header',
          'layouts/header',
          'encomenda_resumo',
          'layouts/footer',
          'layouts/html_footer',
      ], $dados);
    }

    // ====================================================
    public function confirmar_encomenda()
    {
        // guardar dados na base de dados
        $codigo_encomenda = $_SESSION['codigo_encomenda'];
        $total_encomenda = $_SESSION['total_encomenda'];

        $dados = [
            'codigo_encomenda' => $codigo_encomenda,
            'total_encomenda' => $total_encomenda
        ];

        $_SESSION['dados_alternativos'] = [
            'morada' => $_POST['text_morada_alternativa'],
            'cidade' => $_POST['text_cidade_alternativa'],
            'email' => $_POST['text_email_alternativo'],
            'telefone' => $_POST['text_telefone_alternativo'],
        ];

        // enviar email de confirmação da compra
        $dados_encomenda = [];

        $ids = [];

        foreach($_SESSION['carrinho'] as $id_produto => $quantidade)
        {
             array_push($ids, $id_produto);
        }
          
        // Carrinho -----------------------------------------
          
        $ids = implode(",", $ids);
        $produtos = new Produtos();
        $resultados = $produtos->buscar_produtos_por_ids($ids);

        // estrutura dos dados dos produtos
        $string_produtos = [];

        foreach($resultados as $resultado)
        {
            // quantidade
            $quantidade = $_SESSION['carrinho'][$resultado->id_produto];
            
            // string do produto
            $string_produtos[] = "$quantidade x $resultado->nome_produto - R$ ".number_format($resultado->preco, 2, ',', '.'). " / Uni.";
        }

        // lista de produtos para o email
        $dados_encomenda['lista_produtos'] = $string_produtos;

        // preço total da encomenda para o email
        $dados_encomenda['total'] = 'R$ ' . number_format($_SESSION['total_encomenda'], 2, ',', '.');
        
        // dados de pagamento para o email
        $dados_encomenda['dados_pagamento'] = [
            'numero_da_conta' => '123456789',
            'codigo_encomenda' => $_SESSION['codigo_encomenda'],
            'total' => 'R$ ' . number_format($_SESSION['total_encomenda'], 2, ',', '.')
        ];

        // guardar na base de dados a encomenda
        $dados_encomenda=[];
        $dados_encomenda['id_cliente'] = $_SESSION['cliente'];

        // morada
        if(isset($_SESSION['dados_alternativos']['morada']) && !empty($_SESSION['dados_alternativos']['morada']))
        {
            // usa a morada alternativa
            $dados_encomenda['morada'] = $_SESSION['dados_alternativos']['morada'];
            $dados_encomenda['email'] = $_SESSION['dados_alternativos']['email'];
            $dados_encomenda['cidade'] = $_SESSION['dados_alternativos']['cidade'];
            $dados_encomenda['telefone'] = $_SESSION['dados_alternativos']['telefone'];
        }
        else 
        {
            // usa a morada já existente
            $CLIENTE = new Clientes();
            $dados_cliente = $CLIENTE->buscar_dados_cliente($_SESSION['cliente']);
            $dados_encomenda['morada'] = $dados_cliente->morada;
            $dados_encomenda['cidade'] = $dados_cliente->cidade;
            $dados_encomenda['email'] = $dados_cliente->email;
            $dados_encomenda['telefone'] = $dados_cliente->telefone;
        }

        // codigo da encomenda
        $dados_encomenda['codigo_encomenda'] = $_SESSION['codigo_encomenda'];

        // status
        $dados_encomenda['estatus'] = "PENDENTE";
        $dados_encomenda['mensagem'] = "";

        $encomenda = new Encomendas();
        $encomenda->guardar_encomenda($dados_encomenda, $produtos);


        // envio do email para o cliente
        $email = new EnviarEmail();
        $resultado = $email->enviar_email_confirmacao_encomenda($_SESSION['usuario'], $dados_encomenda);

        // Store::printData($dados_encomenda);

        // limpar os dados da encomenda e do carrinho

        // apresenta a página
        Store::Layout([
          'layouts/html_header',
          'layouts/header',
          'confirmar_encomenda',
          'layouts/footer',
          'layouts/html_footer',
        ], $dados);

    }
}
?>
