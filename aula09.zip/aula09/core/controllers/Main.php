<?php 

namespace core\controllers;

use core\classes\Store;

class Main
{
    // ====================================================
    public function index()
    {
        $dados = [
        ];

        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'inicio',
            'layouts/footer',
            'layouts/html_footer',    
        ], $dados);

    }

    // ====================================================
    public function loja()
    {
        echo "LOJA!!!";
    }
}

?>
