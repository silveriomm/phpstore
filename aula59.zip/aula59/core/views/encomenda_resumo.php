<div class="container espaco-fundo">
    <div class="row">
        <div class="col-12">
            <h2>Resumo da sua encomenda</h2>
            <div class="row">
                  <table class='table'>
                    <thead>
                      <tr>
                        <th>Produto</th>
                        <th class="text-center">Quantidade</th>
                        <th class="text-end">Valor Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                          $index = 0;
                          $total_rows = count($carrinho);
                      ?>
                      <?php foreach($carrinho as $produto): ?>
                      <?php if($index < $total_rows-1): ?>
                        <tr>
                          <td class="align-middle"><?= $produto['titulo'] ?></td>
                          <td class="align-middle text-center"><?= $produto['quantidade'] ?></td>
                          <td class="text-end align-middle"><?= 'R$ '.number_format($produto['preco'], 2, ',', '.') ?></td>
                          <td class="text-center align-middle">
                        </tr>
                        <?php else: ?>
                          <td></td>
                          <td class="text-end"><h4>Total:</h4></td>
                          <td class="text-end align-middle"><h4><?= 'R$ '.number_format($produto, 2, ',', '.'); ?></h4></td>
                        <?php endif; ?>
                        <?php $index ++; ?>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                  <div>
                    <!-- Dados do cliente -->
                    <h5 class="bg-dark text-white p-2">Dados do cliente</h5>
                    <div class="row">
                      <div class="col">
                        <p>Nome: <strong><?= $cliente->nome_completo ?></strong></p>
                        <p>Endereço: <strong><?= $cliente->morada ?></strong></p>
                        <p>Cidade: <strong><?= $cliente->cidade ?></strong></p>
                      </div>
                      <div class="col">
                        <p>Email: <strong><?= $cliente->email ?></strong></p>
                    <p>Telefone: <strong><?= $cliente->telefone ?></strong></p>
                      </div>
                    </div>
                  </div>
                  <!-- Dados de pagamento -->
                  <h5 class="bg-dark text-white p-2">Dados do pagamento</h5>
                  <div class="row">
                    <div class="col">
                        <p>Conta bancária: <b>12345678</b></p>
                        <p>Código da encomenda: <b><?= $_SESSION['codigo_encomenda']; ?></b></p>
                        <p>Total: <b><?= 'R$ '.number_format($produto, 2, ',', '.'); ?></b></p>
                    </div>
                  </div>
                  <h5 class="bg-dark text-white p-2">Endereço alternativo</h5>
                  <div class="form-check">
                    <input class="form-check-input" onchange="usar_morada_alternativa()" type="checkbox" name="check_morada_alternativa" id="check_morada_alternativa">
                    <label class="form-check-label" for="check_morada_alternativa"><b>Alterar endereço de envio.</b></label>
                  </div>
                  <form action="?a=confirmar_encomenda" method="POST">
                  <!-- Endereço -->
                  <div id="morada_alternativa" style="display: none;">
                      <!-- Endereço -->
                      <div class="mb-2">
                        <label>Endereço</label>
                        <input class="form-control form-control-sm" type="text" name="text_morada_alternativa">
                   </div>
                   <!-- Cidade -->
                      <div class="mb-2">
                        <label>Cidade</label>
                        <input class="form-control form-control-sm" type="text" name="text_cidade_alternativa">
                   </div>
                   <!-- Email -->
                   <div class="mb-2">
                        <label>Email</label>
                        <input class="form-control form-control-sm" type="text" name="text_email_alternativo">
                    </div>
                    <!-- Telefone -->
                    <div class="mb-2">
                        <label>Telefone</label>
                        <input class="form-control form-control-sm" type="text" name="text_telefone_alternativo">
                    </div>
                  </div>
                  <!-- Fim de endereço -->
                  <div class="row mt-4">
                  <div class="col">
                    <a href="?a=carrinho" class="btn btn-danger">Cancelar</a>
                </div>
                <div class="col text-end">
                    <input type="submit" value="Confirmar compra" class="btn btn-success">
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
