<?php

define('APP_NAME', 'PHPSTORE');
define('APP_VERSION', '1.0.0');

// MYSQL
define('MYSQL_SERVER', 'localhost');
define('MYSQL_DATABASE', 'php_store');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');
define('MYSQL_CHARSET', 'utf8');

?>
