<div class="container-fluid">
    <div class="row mt-3">
        <div class="col md-3">
            <?php
                include(__DIR__ . "/layouts/admin_menu.php")
            ?>   
        </div>
        <div class="col md-9">conteudo</div>
    </div>
</div>
