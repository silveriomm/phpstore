<div>
    <div class="mb-3">
        <i class="fas fa-times me-2"></i><a href="#">Início</a>
    </div>
    <div class="mb-3">
        <i class="fas fa-times me-2"></i><a href="#">Clientes</a>
    </div>
    <div class="mb-3">
        <i class="fas fa-times me-2"></i><a href="#">Encomendas</a>
    </div>
</div>
