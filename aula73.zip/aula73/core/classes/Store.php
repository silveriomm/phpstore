<?php 

namespace core\classes;
use Exception;

class Store
{
    // ====================================================
    public static function layout($estruturas, $dados = null)
    {
        // verifica se estruturas é um array
        if(!is_array($estruturas))
        {
            throw new Exception("Coleção de estruturas inválidas.");
        }

        // variáveis
        if(!empty($dados) && is_array($dados))
        {
            extract($dados);
        }

        // apresentar as views
        foreach($estruturas as $estrutura)
        {
            include("../core/views/$estrutura.php");
        }

    }
    
    // ====================================================
    public static function layout_admin($estruturas, $dados = null)
    {
        // verifica se estruturas é um array
        if(!is_array($estruturas))
        {
            throw new Exception("Coleção de estruturas inválidas.");
        }

        // variáveis
        if(!empty($dados) && is_array($dados))
        {
            extract($dados);
        }

        // apresentar as views
        foreach($estruturas as $estrutura)
        {
            include("../../core/views/$estrutura.php");
        }

    }   
    
    // ====================================================
    public static function clienteLogado()
    {
        // verifica se existe um cliente logado
        return isset($_SESSION['cliente']);
    }
    
    // ====================================================
    public static function adminLogado()
    {
        // verifica se existe um cliente logado
        return isset($_SESSION['admin']);
    }
    
    // ====================================================
    public static function criarHash($num_caracteres = 12)
    {
        // criar hashes
        $chars = '0123456789abcdefghijklmnopqrstuwvxyzABCDEFGHIJKLMNOPQRSTUWVXYZ';
        return substr(str_shuffle($chars), 0, $num_caracteres);
    }
    
    // ====================================================
    public static function redirect($rota = "", $admin = false)
    {
        // faz redirecionamento para a rota desejada
        if(!$admin)
        {
            header("Location: " . BASE_URL . "?a=$rota");
        }
        else 
        {
            header("Location: " . BASE_URL . "/admin?a=$rota");
        }
    }
    
    // ====================================================
    public static function printData($data)
    {
        if(is_array($data) || is_object($data))
        {
            echo '<pre>';
            print_r($data);
        }
        else
        {
            echo '<pre>';
            echo $data;
        }

        die('<hr>fim de printData');
    }

    // ====================================================
    public static function gerar_codigo_encomenda()
    {
        // gerar código para a encomenda
        $codigo = "";
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codigo .= substr(str_shuffle($chars), 0, 2);
        $codigo .= rand(100000, 999999);

        return $codigo;
    }
    
    // ====================================================
    public static function aesEncriptar($valor)
    {
        return bin2hex(openssl_encrypt($valor, 'aes-256-cbc', AES_KEY, OPENSSL_RAW_DATA, AES_IV));
    }

    // ====================================================
    public static function aesDesencriptar($valor)
    {
        return openssl_decrypt(hex2bin($valor), 'aes-256-cbc', AES_KEY, OPENSSL_RAW_DATA, AES_IV);
    }
}

?>
