-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.7.33 - MySQL Community Server (GPL)
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para php_store
CREATE DATABASE IF NOT EXISTS `php_store` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `php_store`;

-- Copiando estrutura para tabela php_store.admins
CREATE TABLE IF NOT EXISTS `admins` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela php_store.admins: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;

-- Copiando estrutura para tabela php_store.clientes
CREATE TABLE IF NOT EXISTS `clientes` (
  `id_cliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_completo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `morada` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purl` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(3) unsigned DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cliente`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela php_store.clientes: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` (`id_cliente`, `email`, `senha`, `nome_completo`, `morada`, `cidade`, `telefone`, `purl`, `activo`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(9, 'silveriomm@bol.com.br', '$2y$10$/xpVB8Lvio7m7U7oJM8uI.NSrlaKTYC15zIkPGqj6t0.yDNIzkwwu', 'Jota', 'Avenida doutor Valério, 317', 'Vila Valério', '995303264', NULL, 1, '2022-02-22 21:20:57', '2022-03-12 15:21:04', NULL),
	(10, 'silverio@bol.com.br', '$2y$10$q1Q8nOzkjHLX2NWebN8HF.xFeeB0cZAuQYhmVTRBs3TvcLMZmOgm2', 'Silvério Gonçalves', 'Avenida doutor Valério, 3', 'Vila Valério', '32265655', NULL, 1, '2022-02-22 21:20:57', '2022-02-22 21:21:17', NULL),
	(11, 'paulo@miranda.com', '$2y$10$q1Q8nOzkjHLX2NWebN8HF.xFeeB0cZAuQYhmVTRBs3TvcLMZmOgm2', 'Paulo Miranda', 'rua das camélias, 345', 'Linhares', '65124877', NULL, 1, '2022-02-22 21:20:57', '2022-03-12 12:30:28', NULL);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;

-- Copiando estrutura para tabela php_store.encomendas
CREATE TABLE IF NOT EXISTS `encomendas` (
  `id_encomenda` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `data_encomenda` datetime DEFAULT CURRENT_TIMESTAMP,
  `morada` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_encomenda` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estatus` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensagem` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_encomenda`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela php_store.encomendas: ~10 rows (aproximadamente)
/*!40000 ALTER TABLE `encomendas` DISABLE KEYS */;
INSERT INTO `encomendas` (`id_encomenda`, `id_cliente`, `data_encomenda`, `morada`, `cidade`, `email`, `telefone`, `codigo_encomenda`, `estatus`, `mensagem`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 9, '2022-03-10 22:09:56', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'OB314827', 'EM PROCESSAMENTO', '', '2022-03-10 22:09:56', '2022-03-15 15:46:07', NULL),
	(2, 9, '2022-03-10 22:12:52', 'rua do ouvidor, 33', 'Colatina', 'ahsousilverio@gmail.com', '', 'DO171443', 'PENDENTE', '', '2022-03-10 22:12:52', '2022-03-10 22:12:52', NULL),
	(3, 9, '2022-03-10 22:30:56', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'FY930865', 'PENDENTE', '', '2022-03-10 22:30:56', '2022-03-10 22:30:56', NULL),
	(4, 9, '2022-03-10 22:33:03', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'PH430900', 'PENDENTE', '', '2022-03-10 22:33:03', '2022-03-10 22:33:03', NULL),
	(5, 9, '2022-03-10 22:34:23', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'YJ600422', 'PENDENTE', '', '2022-03-10 22:34:23', '2022-03-10 22:34:23', NULL),
	(6, 9, '2022-03-10 22:37:20', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'FO610114', 'PENDENTE', '', '2022-03-10 22:37:20', '2022-03-10 22:37:20', NULL),
	(7, 9, '2022-03-10 22:39:18', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'YJ376900', 'PENDENTE', '', '2022-03-10 22:39:18', '2022-03-10 22:39:18', NULL),
	(8, 9, '2022-03-10 22:42:35', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'UK506056', 'PENDENTE', '', '2022-03-10 22:42:35', '2022-03-10 22:42:35', NULL),
	(9, 9, '2022-03-10 22:44:04', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'GB832207', 'PENDENTE', '', '2022-03-10 22:44:04', '2022-03-10 22:44:04', NULL),
	(10, 9, '2022-03-12 12:36:51', 'Avenida doutor Valério, 317', 'Vila Valério', 'silveriomm@bol.com.br', '995303264', 'UL299684', 'PENDENTE', '', '2022-03-12 12:36:51', '2022-03-12 12:36:51', NULL);
/*!40000 ALTER TABLE `encomendas` ENABLE KEYS */;

-- Copiando estrutura para tabela php_store.encomenda_produto
CREATE TABLE IF NOT EXISTS `encomenda_produto` (
  `id_encomenda_produto` int(11) NOT NULL AUTO_INCREMENT,
  `id_encomenda` int(11) DEFAULT NULL,
  `designacao_produto` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preco_unidade` decimal(11,2) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_encomenda_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela php_store.encomenda_produto: ~23 rows (aproximadamente)
/*!40000 ALTER TABLE `encomenda_produto` DISABLE KEYS */;
INSERT INTO `encomenda_produto` (`id_encomenda_produto`, `id_encomenda`, `designacao_produto`, `preco_unidade`, `quantidade`, `created_at`) VALUES
	(1, 1, 'Tshirt Vermelha', 45.70, 1, '2022-03-10 22:09:56'),
	(2, 1, 'Tshirt Azul', 55.25, 1, '2022-03-10 22:09:56'),
	(3, 2, 'Vertido Azul', 86.00, 3, '2022-03-10 22:12:52'),
	(4, 3, 'Tshirt Vermelha', 45.70, 1, '2022-03-10 22:30:56'),
	(5, 3, 'Tshirt Azul', 55.25, 1, '2022-03-10 22:30:56'),
	(6, 3, 'Vestido Vermelho', 75.20, 2, '2022-03-10 22:30:56'),
	(7, 3, 'Vestido Amarelo', 46.45, 1, '2022-03-10 22:30:56'),
	(8, 3, 'Blusa vermelha', 34.50, 3, '2022-03-10 22:30:56'),
	(9, 4, 'Tshirt Vermelha', 45.70, 1, '2022-03-10 22:33:03'),
	(10, 4, 'Tshirt Azul', 55.25, 1, '2022-03-10 22:33:03'),
	(11, 5, 'Tshirt Vermelha', 45.70, 1, '2022-03-10 22:34:23'),
	(12, 5, 'Tshirt Azul', 55.25, 2, '2022-03-10 22:34:23'),
	(13, 6, 'Vestido Verde', 48.85, 2, '2022-03-10 22:37:20'),
	(14, 6, 'Vestido Forido', 46.60, 2, '2022-03-10 22:37:21'),
	(15, 6, 'Blusa vermelha', 34.50, 2, '2022-03-10 22:37:21'),
	(16, 6, 'Vestido rosa', 23.40, 2, '2022-03-10 22:37:21'),
	(17, 7, 'Tshirt Azul', 55.25, 2, '2022-03-10 22:39:18'),
	(18, 8, 'Tshirt Vermelha', 45.70, 3, '2022-03-10 22:42:35'),
	(19, 8, 'Tshirt Azul', 55.25, 1, '2022-03-10 22:42:35'),
	(20, 9, 'Tshirt Vermelha', 45.70, 3, '2022-03-10 22:44:04'),
	(21, 10, 'Tshirt Vermelha', 45.70, 2, '2022-03-12 12:36:51'),
	(22, 10, 'Tshirt Azul', 55.25, 1, '2022-03-12 12:36:51'),
	(23, 10, 'Vestido Vermelho', 75.20, 1, '2022-03-12 12:36:51');
/*!40000 ALTER TABLE `encomenda_produto` ENABLE KEYS */;

-- Copiando estrutura para tabela php_store.produtos
CREATE TABLE IF NOT EXISTS `produtos` (
  `id_produto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoria` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_produto` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagem` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `visivel` tinyint(4) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela php_store.produtos: ~12 rows (aproximadamente)
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` (`id_produto`, `categoria`, `nome_produto`, `descricao`, `imagem`, `preco`, `stock`, `visivel`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'homem', 'Tshirt Vermelha', 'Ab laborum, commodi aspernatur, quas distinctio cum quae omnis autem ea, odit sint quisquam similique! Labore aliquam amet veniam ad fugiat optio.', 'tshirt_vermelha.png', 45.70, 100, 1, '2021-02-06 19:45:18', '2021-02-06 19:45:25', NULL),
	(2, 'homem', 'Tshirt Azul', 'Possimus iusto esse atque autem rem, porro officiis sapiente quos velit laboriosam id expedita odio obcaecati voluptate repudiandae dignissimos eveniet repellat blanditiis.', 'tshirt_azul.png', 55.25, 100, 1, '2021-02-06 19:45:19', '2021-02-06 19:45:25', NULL),
	(3, 'homem', 'Tshirt Verde', 'Nostrum quisquam dolorum dolor autem accusamus fugit nesciunt, atque et? Quis eum nemo quidem officia cum dolorem voluptates! Autem, earum. Similique, fugit.', 'tshirt_verde.png', 35.15, 0, 1, '2021-02-06 19:45:20', '2021-02-06 19:45:26', NULL),
	(4, 'homem', 'Tshirt Amarela', 'Molestiae quaerat distinctio, facere perferendis necessitatibus optio repellat alias commodi voluptatem velit corrupti natus exercitationem quos amet facilis sint nulla delectus.', 'tshirt_amarela.png', 32.00, 100, 1, '2021-02-06 19:45:20', '2021-02-06 19:45:27', NULL),
	(5, 'mulher', 'Vestido Vermelho', 'Labore voluptatem sed in distinctio iste tempora quo assumenda impedit illo soluta repudiandae animi earum suscipit, sequi excepturi inventore magnam velit voluptatibus.', 'dress_vermelho.png', 75.20, 100, 1, '2021-02-06 19:45:21', '2021-02-06 19:45:27', NULL),
	(6, 'mulher', 'Vertido Azul', 'Provident ipsum earum magnam odit in, illum nostrum est illo pariatur molestias esse delectus aliquam ullam maxime mollitia tempore, sunt officia suscipit.', 'dress_azul.png', 86.00, 100, 1, '2021-02-06 19:45:21', '2021-02-06 19:45:28', NULL),
	(7, 'mulher', 'Vestido Verde', 'Qui aliquid sed quisquam autem quas recusandae labore neque laudantium iusto modi repudiandae doloremque ipsam ad omnis inventore, cum ducimus praesentium. Consectetur!', 'dress_verde.png', 48.85, 100, 1, '2021-02-06 19:45:22', '2021-02-06 19:45:28', NULL),
	(8, 'mulher', 'Vestido Amarelo', 'Aspernatur labore corporis modi quis temporibus eos hic? Sed fugiat, repudiandae distinctio, labore temporibus, non magni consectetur dolorum earum amet impedit nesciunt.', 'dress_amarelo.png', 46.45, 100, 1, '2021-02-06 19:45:22', '2021-02-06 19:45:29', NULL),
	(12, 'mulher', 'Vestido Jeans Azul', 'Aspernatur labore corporis modi quis temporibus eos hic? Sed fugiat, repudiandae distinctio, labore temporibus, non magni consectetur dolorum earum amet impedit nesciunt.', 'vestido_azul.png', 56.70, 100, 1, '2022-03-09 09:57:52', '2022-03-09 09:58:29', NULL),
	(13, 'mulher', 'Vestido Forido', 'Aspernatur labore corporis modi quis temporibus eos hic? Sed fugiat, repudiandae distinctio, labore temporibus, non magni consectetur dolorum earum amet impedit nesciunt.', 'vestido-florido.png', 46.60, 100, 1, '2022-03-09 09:59:09', '2022-03-09 09:59:09', NULL),
	(14, 'mulher', 'Blusa vermelha', 'Aspernatur labore corporis modi quis temporibus eos hic? Sed fugiat, repudiandae distinctio, labore temporibus, non magni consectetur dolorum earum amet impedit nesciunt.', 'blusa_vermelha.png', 34.50, 100, 1, '2022-03-09 10:00:08', '2022-03-09 10:00:08', NULL),
	(15, 'criança', 'Vestido rosa', 'Aspernatur labore corporis modi quis temporibus eos hic? Sed fugiat, repudiandae distinctio, labore temporibus, non magni consectetur dolorum earum amet impedit nesciunt.', 'vestido-rosa.png', 23.40, 100, 1, '2022-03-09 10:00:57', '2022-03-09 10:00:57', NULL);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
