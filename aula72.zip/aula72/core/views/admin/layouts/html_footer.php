
</body>
  <script src="../assets/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/bundle.min.js"></script>
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/axios.min.js"></script>
  <script src="../assets/js/app.js"></script>
</html>
