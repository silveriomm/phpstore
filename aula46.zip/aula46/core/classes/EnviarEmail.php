<?php

namespace core\classes;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class EnviarEmail{

    // ====================================================
    public function enviar_email_confirmacao_novo_cliente($email_cliente, $purl){
        // constroi o link com o purl
        $link = BASE_URL . '?a=confirmar_email&purl=' . $purl;

        // envia um email para o novo cliente
        $mail = new PHPMailer(true);

        try {
            // configurações do servidor
            $mail->SMTPDebug = SMTP::DEBUG_OFF;
            $mail->isSMTP();                        
            $mail->Host       = EMAIL_HOST;
            $mail->SMTPAuth   = true;                       
            $mail->Username   = EMAIL_FROM;  
            $mail->Password   = EMAIL_PASS;                    
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
            $mail->Port       = EMAIL_PORT;                        

            // emissor e receptor
            $mail->setFrom(EMAIL_FROM, APP_NAME);
            $mail->addAddress($email_cliente);
            $mail->CharSet = 'UTF-8';

            // conteúdo
            $mail->isHTML(true);                    
            $mail->Subject = APP_NAME . ' - Confirmação de email.';
           
           // mensagem
            $html = '<p>Seja bem-vindo à nossa loja ' . APP_NAME .'.</p>';
            $html .= '<p>Para poder acessar a loja, necessita confirmar o seu email.</p>';
            $html .= '<p>Para confirmar o email, clique no link abaixo:</p>';
            $html .= '<p><a href="'.$link.'">Confirmar email</a></p>';
            $html .= '<p><i>'.APP_NAME.'</i></p>';
           
            $mail->Body    = $html;

            $mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    // ====================================================
    public function enviar_email_confirmacao_encomenda($email_cliente, $dados_encomenda){

        // envia um email para o novo cliente
        $mail = new PHPMailer(true);

        try {
            // configurações do servidor
            $mail->SMTPDebug = SMTP::DEBUG_OFF;
            $mail->isSMTP();                        
            $mail->Host       = EMAIL_HOST;
            $mail->SMTPAuth   = true;                       
            $mail->Username   = EMAIL_FROM;  
            $mail->Password   = EMAIL_PASS;                    
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
            $mail->Port       = EMAIL_PORT;                        

            // emissor e receptor
            $mail->setFrom(EMAIL_FROM, APP_NAME);
            $mail->addAddress($email_cliente);
            $mail->CharSet = 'UTF-8';

            // conteúdo
            $mail->isHTML(true);                    
            $mail->Subject = APP_NAME . ' - Confirmação de encomenda.';
           
           // mensagem
            $html = '';
           
            $mail->Body    = $html;

            $mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }


}
