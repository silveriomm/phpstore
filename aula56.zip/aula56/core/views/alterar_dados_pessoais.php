<div class="col-6 offset-sm-3">
    <h3 class="text-center">Alterar dados</h3>
    <form>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="text_email" value="<?= $dados_pessoais->email ?>" class="form-control form-control-sm" disabled>
        </div>
        <div class="form-group">
            <label>Nome</label>
            <input type="text" name="text_nome_completo" value="<?= $dados_pessoais->nome_completo ?>" class="form-control form-control-sm">
        </div>
        <div class="form-group">
            <label>Endereço</label>
            <input type="text" name="text_morada" value="<?= $dados_pessoais->morada ?>" class="form-control form-control-sm">
        </div>
        <div class="form-group">
            <label>Cidade</label>
            <input type="text" name="text_cidade" value="<?= $dados_pessoais->cidade ?>" class="form-control form-control-sm">
        </div>
        <div class="form-group">
            <label>Telefone</label>
            <input type="text" name="text_telefone" value="<?= $dados_pessoais->telefone ?>" class="form-control form-control-sm">
        </div>
        <div class="text-center mt-3">
            <a href="?a=perfil" class=" btn btn-danger">Cancelar</a>
            <input type="submit" value="Alterar" class=" btn btn-success">
        </div>
    </form>
</div>
