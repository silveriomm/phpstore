<div class"container-fluid">
    <div class="row my-2">
        <div class="col-sm-6 offset-sm-3">
            <h3 class="text-center">Adicionar Novo Cliente</h3>
            <form action="?a=criar_cliente" method="post">
                <!-- Email -->
                <div class="my-1">
                    <label>Email</label>
                    <input type="email" name="text_email" class="form-control form-control-sm" required autofocus>
                </div>
                <!-- Senha -->
                <div class="my-1">
                    <label>Senha</label>
                    <input type="password" name="text_senha_1" class="form-control form-control-sm" required>
                </div>
                <!-- Senha 2 -->
                <div class="my-1">
                    <label>Confirma Senha</label>
                    <input type="password" name="text_senha_2" class="form-control form-control-sm" required>
                </div>
                <!-- Nome completo -->
                <div class="my-1">
                    <label>Nome</label>
                    <input type="text" name="text_nome_completo" class="form-control form-control-sm" required>
                </div>
                <!-- Endereço -->
                <div class="my-1">
                    <label>Endereço</label>
                    <input type="text" name="text_morada" class="form-control form-control-sm" required>
                </div>
                <!-- Cidade -->
                <div class="my-1">
                    <label>Cidade</label>
                    <input type="text" name="text_cidade" class="form-control form-control-sm" required>
                </div>
                <!-- Telefone -->
                <div class="my-1">
                    <label>Telefone</label>
                    <input type="text" name="text_telefone" class="form-control form-control-sm">
                </div>
                <!-- Submit -->
                <div class="my-2 text-center">
                    <input type="submit" value="Criar conta" class="btn btn-primary">
                </div>
                <?php if(isset($_SESSION['erro'])): ?>
                    <div class="alert alert-danger text-center">
                        <?= $_SESSION['erro']; ?>
                        <?php unset($_SESSION['erro']); ?>
                    </div>
                <?php endif;?>
            </form>
        </div>
    </div>
</div>
