<div class="container espaco-fundo">
    <div class="row">
        <div class="col-12">
            <h1>Sua encomenda</h1><hr>
            <div class="row">
                <?php if($carrinho == null): ?>
                    <p class="text-center">Não existem produtos no carrinho</p>

                <div class="row">
                <div class="col text-center">
                <a href="?a=loja" class="btn btn-primary btn-sm">Ir para a loja</a>
                </div>
                </div>
                <?php else: ?>

                  <table class='table'>
                    <thead>
                      <tr>
                        <th></th>
                        <th>Produto</th>
                        <th class="text-center">Quantidade</th>
                        <th class="text-end">Valor Total</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                          $index = 0;
                          $total_rows = count($carrinho);
                      ?>
                      <?php foreach($carrinho as $produto): ?>
                      <?php if($index < $total_rows-1): ?>
                        <tr>
                          <td><img class="img-fluid" width="50" src="assets/images/produtos/<?= $produto['imagem']; ?>"></td>
                          <td class="align-middle"><?= $produto['titulo'] ?></td>
                          <td class="align-middle text-center"><b><?= $produto['quantidade'] ?></b></td>
                          <td class="text-end align-middle"><b><?= 'R$ '.str_replace('.',',', $produto['preco']) ?></b></td>
                          <td class="text-center align-middle">
                          <buttom class="btn btn-danger btn-sm">
                            <i class="fas fa-times"></i>
                          </buttom>
                          </td>
                        </tr>
                        <?php else: ?>
                          <td></td>
                          <td></td>
                          <td class="text-end"><h4><b>Total:</b></h4></td>
                          <td class="text-end align-middle"><h4><b><?= 'R$ '.str_replace('.',',', $produto); ?></h4><b></td>
                          <td></td>
                        <?php endif; ?>
                        <?php $index ++; ?>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                  <div class="row">
                  <div class="col">
                <a href="?a=limpar_carrinho" class="btn btn-sm btn-warning">Limpar carrinho</a>
                </div>
                <div class="col text-end">
                <a href="?a=loja" class="btn btn-primary btn-sm">Continuar a comprar</a>
                <a href="#" class="btn btn-sm btn-success">Finalizar compra</a>
                </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
