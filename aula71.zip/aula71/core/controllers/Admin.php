<?php 

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;

class Admin
{
    // ====================================================================
    public function index()
    {
        // verifica se já existe amdin logado
        if(!Store::adminLogado()) {
            Store::redirect('admin_login', true);
            return;           
        }

        // apresenta a página de Admin
        Store::layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }
    
    // ====================================================================
    public function admin_login()
    {
        // verifica se já existe amdin logado
        if(Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;           
        }

        // Apresenta o login do Admin
        Store::layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/login_frm',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }
    
    // ====================================================================
    public function lista_clientes()
    {
        echo "lista de clientes";
    }
}

?>
