<div class="container">
    <div class="row">
        <div class="col-sm-4 offset-sm-4">
            <h1 class="text-center my-5">Administração</h1>
            <form action="?a=login_submit" method="post">
              <div class="my-3">
                <label>Administrador</label>
                <input class="form-control form-control-sm" type="email" name="text_admin" required autofocus">
              </div>
              <div class="my-3">
                <label>Senha</label>
                <input class="form-control form-control-sm" type="password" name="text_senha" required>
              </div>
              <div class="my-3 text-center">
                <input class="btn btn-primary" type="submit" value="Entrar">
              </div>
            </form>
            <?php if(isset($_SESSION['erro'])): ?>
              <div class="alert alert-danger p-1 text-center">
                <?= $_SESSION['erro']; ?>
                <?php unset($_SESSION['erro']); ?>
              </div>
            <?php endif; ?>
        </div>
    </div>
</div>
