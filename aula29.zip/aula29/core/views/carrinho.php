<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h1>Carrinho</h1>
            <button class="btn btn-primary btn-sm" onclick="limpar_carrinho()">Limpar</button>
            <pre>
            <?php print_r($_SESSION); ?>
            </pre>
        </div>
    </div>
</div>
