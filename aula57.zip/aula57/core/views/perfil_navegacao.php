<div class="container-fluid">
    <div class="row my-3">
        <div class="text-center">
            <a href="?a=alterar_dados_pessoais" class="mx-3 btn btn-secondary btn-sm"><i class="fas fa-edit"></i> Alterar dados pessoais</a>
            <a href="?a=alterar_password" class="mx-3 btn btn-secondary btn-sm"><i class="fas fa-lock"></i> Alterar a senha</a>
            <a href="?a=historico_encomendas" class="mx-3 btn btn-secondary btn-sm"><i class="fas fa-list"></i> Histórico de encomendas</a>
        </div>
    </div>
</div>
