<div class="container">
    <div class="row my-5">
        <div class="col-sm-6 offset-sm-3">
            <h3 class="text-center">Encomenda confirmada.</h3>
            <h4 class="text-center"><b>Muito obrigado pela compra.</b></h4>
            <div class="card my-3 p-2">
                <h5>Dados de pagamento</h5>
                <p>Conta Bancária: <b>123456789</b></p>
                <p>Código da encomenda: <strong><?=  $codigo_encomenda; ?></strong></p>
                <p>Total da encomenda: <strong>R$ <?=  number_format($total_encomenda, 2,  ',', '.'); ?></strong></p>
            </div>
            <p>Você vai receber um email com a confirmação da encomenda.</p>
            <p> A sua encomenda só será processada após a confirmação do pagamento.</p><br>
            <p><small>Por favor verifique se o email aparece na sua conta, ou se foi para a pasta do spam.</small></p>
            <div class="my-4 text-center">
                <a href="?a=inicio" class="btn btn-primary">Voltar</a>
            </div>
        </div>
    </div>
</div>
