<?php

define('APP_NAME', 'PHPSTORE');
define('APP_VERSION', '1.0.0');

?>
