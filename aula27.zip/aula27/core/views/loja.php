<?php

  print_r($_SESSION);

?>
<div class="container espaco-fundo">
    <div class="row">
        <div class="col-12 text-center my-4">
            <a class="btn btn-primary btn-sm" href="?a=loja&c=todos">Todos</a>
            <?php foreach($categorias as $categoria): ?>
              <a class="btn btn-primary btn-sm" href="?a=loja&c=<?= $categoria; ?>">
                <?= ucfirst(preg_replace("/\_/", " ", $categoria)); ?>
              </a>
            <?php endforeach;?>
        </div>
    </div>
    <div class="row">
        <?php if(count($produtos) == 0): ?>
              <div class="text-center my-5">
                <h4>Não existem produtos disponíveis.</h4>
              </div>
        <?php else: ?>
              <?php foreach($produtos as $produto): ?>
              <div class="col-sm-4 col-6 p-2">
              <div class="text-center p-3 box-produto">
                <img class="img-fluid" src="assets/images/produtos/<?= $produto->imagem ?>">
                <h4><?= $produto->nome_produto ?></h4>
                <h2>R$ <?= preg_replace("/\./", ",", $produto->preco) ?></h2>
                <div>
                    <button onclick="adicionar_carrinho(<?= $produto->id_produto ?>)" class="btn btn-primary btn-sm">
                      <i class="fas fa-shopping-cart"></i> Adicionar ao carrinho
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>


    </div>
</div>
