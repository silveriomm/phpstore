<h1> <?= $titulo ?> </h1>

<?php foreach($clientes as $cliente): ?>
    <p> <?= $cliente ?> </p>
<?php endforeach; ?>
