<?php 

// use core\classes\Database;
// use core\classes\Store;

// abrir a sessão
session_start();

// carregar o config
require_once('../config.php');

// carrega todas as classes do projeto
require_once('../vendor/autoload.php');

// carrega o sistema de rotas
require_once('../core/rotas.php');

// $bd = new Database();
// $users = $bd->select('SELECT * FROM usuarios');
// echo '<pre>';
// print_r($users);


?>
