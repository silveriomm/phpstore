<div class="container-fluid">
    <div class="row">
        <div class="col-12 my-5">
            <h1 class="text-center my-5">Bem-vindo a PHPSTORE!</h1>
        </div>
    </div>
</div>
