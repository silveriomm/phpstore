<div class="container-fluid espaco-fundo">
    <div class="row">
        <div class="col-12 text-center">
            <h1>Loja Online</h1>
        </div>
    </div>
    <div class="row">
        <?php foreach($produtos as $produto): ?>
        <div class="col-sm-4">
            <div class="text-center p-3">
                <img class="img-fluid" src="assets/images/produtos/<?= $produto->imagem ?>">
                <h4><?= $produto->nome_produto ?></h4>
                <h2><?= $produto->preco ?></h2>
                <p><small><?= $produto->descricao ?></small></p>
                <div>
                    <button class="btn btn-primary btn-sm">Adicionar ao carrinho</button>
                </div>
            </div> 
        </div>
        <?php endforeach; ?>
    </div>
</div>
