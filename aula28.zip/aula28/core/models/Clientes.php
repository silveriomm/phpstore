<?php

namespace core\models;

use core\classes\Database;
use core\classes\Store;

class Clientes
{
    // ====================================================
    public function verificar_email_existe($email)
    {
        // verifica se existe cliente com o mesmo email
        $bd = new Database();
        $parametros = [
            ':email' => strtolower(trim($email))
        ];
        $resultados = $bd->select("SELECT email FROM clientes WHERE email = :email", $parametros);

        // se o cliente já existe
        if(count($resultados) != 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    // ====================================================
    public function registrar_cliente()
    {
        $bd = new Database();

         // criação do purl
        $purl = Store::criarHash();

        // pega dados do formulário
        $parametros = [
            ':email' => strtolower(trim($_POST['text_email'])),
            ':senha' => password_hash($_POST['text_senha_1'], PASSWORD_DEFAULT),
            ':nome_completo' => trim($_POST['text_nome_completo']),
            ':morada' => trim($_POST['text_morada']),
            ':cidade' => trim($_POST['text_cidade']),
            ':telefone' => trim($_POST['text_telefone']),
            ':purl' => $purl,
            'activo' => 0,
        ];

        // insere o novo cliente
        $bd->insert("
            INSERT INTO clientes
            VALUES(
                0,
                :email,
                :senha,
                :nome_completo,
                :morada,
                :cidade,
                :telefone,
                :purl,
                :activo,
                NOW(),
                NOW(),
                NULL
            )
        ", $parametros);

        // retorna o purl criado
        return $purl;
    }

    // ====================================================
    public function validar_email($purl)
    {
        // validar o email do novo cliente
        $bd = new Database();
        $parametros = [
            ':purl' => $purl
        ];
        $resultados = $bd->select("
                                   SELECT * FROM clientes 
                                   WHERE purl = :purl", $parametros);

        // verifica se foi encontrado o cliente
        if(count($resultados) != 1)
        {
            return false;
        }

        // foi encontrado o cliente
        $id_cliente = $resultados[0]->id_cliente;

        // atualizar os dados do cliente
        $parametros = [
            ':id_cliente' => $id_cliente
        ];
        $bd->update("
            UPDATE clientes SET
            purl = NULL,
            activo = 1,
            updated_at = NOW()
            WHERE id_cliente = :id_cliente
        ", $parametros);

        return true;
    }

    // ====================================================
    public function validar_login($usuario, $senha)
    {
      // verifica se o login é válido
      $parametros = [
        ':usuario' => $usuario
      ];

      $bd = new Database();
      $resultados = $bd->select("
        SELECT * FROM clientes
        WHERE email = :usuario
        AND activo = 1
        AND deleted_at IS NULL
      ", $parametros);

      if(count($resultados) != 1)
      {
        // não existe usuário
        return false;
      }
      else
      {
        // temos o usuário
        $usuario = $resultados[0];
      }

      // verifica a senha
      if(!password_verify($senha, $usuario->senha))
      {
          // senha inválida
          return false;
      }
      else
      {
          // login válido
          return $usuario;
      }
    }

    // ====================================================
}

?>
