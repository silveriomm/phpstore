<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h1>Carrinho</h1>
            <pre>
            <?php print_r($_SESSION); ?>
            </pre>
        </div>
    </div>
</div>
