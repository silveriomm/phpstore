<?php

define('APP_NAME', 'PHPSTORE');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/PHPSTORE/public/');

// MYSQL
define('MYSQL_SERVER', 'localhost');
define('MYSQL_DATABASE', 'php_store');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');
define('MYSQL_CHARSET', 'utf8');

// Email
define('EMAIL_HOST', 'smtp.gmail.com');
define('EMAIL_FROM', 'lindophacarhai@gmail.com');
define('EMAIL_PASS', 'Silvi04550');
define('EMAIL_PORT', 587);

?>
