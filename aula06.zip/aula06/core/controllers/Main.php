<?php 

namespace core\controllers;

class Main
{
    public function index()
    {
        echo "MAIN!!!";
    }

    public function loja()
    {
        echo "LOJA!!!";
    }
}

?>
