<div class="col-4 offset-sm-4">
    <h3 class="text-center">Alterar senha</h3>
    <form action="?a=alterar_password_submit" method="post">
        <div class="form-group">
            <label>Senha atual</label>
            <input type="password" max_length="30" name="text_senha_atual" class="form-control form-control-sm" required>
        </div>
        <div class="form-group">
            <label>Nova senha</label>
            <input type="password" name="text_nova_senha" max_length="30" class="form-control form-control-sm" required>
        </div>
        <div class="form-group">
            <label>Repetir nova senha</label>
            <input type="password" max_length="30" name="text_repetir_nova_senha" class="form-control form-control-sm" required>
        </div>
        <div class="text-center mt-3">
            <a href="?a=perfil" class=" btn btn-danger btn-100">Cancelar</a>
            <input type="submit" value="Alterar" class=" btn btn-success btn-100">
        </div>
    </form>
    <?php if(isset($_SESSION['erro'])): ?>
        <div class="alert alert-danger my-2 text-center">
            <?= $_SESSION['erro']; ?>
            <?php unset($_SESSION['erro']); ?>
        </div>
    <?php endif; ?>
</div>
