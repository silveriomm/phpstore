<?php 

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;
use core\models\AdminModel;

class Admin
{
    // ====================================================================
    public function index()
    {
        // temp

        // verifica se já existe amdin logado
        if(!Store::adminLogado()) {
            Store::redirect('admin_login', true);
            return;           
        }

        // verifica se existe encomendas pendentes
        $ADMIN = new AdminModel();
        $encomendas_pendentes = $ADMIN->lista_encomendas_pendentes();

        // apresenta a página de Admin
        Store::layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }
    
    // ====================================================================
    public function admin_login()
    {
        // verifica se já existe amdin logado
        if(Store::adminLogado()) {
            Store::redirect('inicio', true);
            return;           
        }

        // Apresenta o login do Admin
        Store::layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/login_frm',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }
    
    // ====================================================================
    public function admin_login_submit()
    {
        // veirificar se já existe um admin logado
        if(Store::adminLogado())
        {
            Store::redirect('inicio', true);
            return;
        }

        // verifica se foi efetuado um post
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            Store::redirect('inicio', true);
            return;
        }

        // validar se os campos foram preenchidos
        if(
          !isset($_POST['text_admin']) ||
          !isset($_POST['text_senha']) ||
          !filter_var(trim($_POST['text_admin']), FILTER_VALIDATE_EMAIL)
        )
        {
          // erro de preenchimento do formulário
          $_SESSION['erro'] = 'Usuário ou senha inválidos.';
          Store::redirect('admin_login', true);
          return;
        }

        // prepara os dados para o model
        $admin = trim(strtolower($_POST['text_admin']));
        $senha = trim($_POST['text_senha']);

        // carrega o model e verifica se o login é válido
        $admin_model = new AdminModel();
        $resultado = $admin_model->validar_login($admin, $senha);

        // analisa o resultado
        if(is_bool($resultado))
        {
          // login inválido
          $_SESSION['erro'] = 'Usuário ou senha inválidos.';
          Store::redirect('admin_login', true);
          return;
        }
        else
        {
          // login válido
          $_SESSION['admin'] = $resultado->id_admin;
          $_SESSION['admin_usuario'] = $resultado->usuario;

          // redireciona para a página administrativa
          Store::redirect('inicio', true);
        }    
    }

    // ====================================================================
    public function admin_logout()
    {
        // faz o logout do admin
        unset($_SESSION['admin']);
        unset($_SESSION['admin_usuario']);

        //redireciona para o ínicio do admin
        Store::redirect('inicio', true);
    }
    
    // ====================================================================
    public function lista_clientes()
    {
        echo "lista de clientes";
    }
}

?>
