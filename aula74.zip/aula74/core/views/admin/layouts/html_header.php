<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title> <?= APP_NAME; ?> </title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/app.css">
</head>
<body>

