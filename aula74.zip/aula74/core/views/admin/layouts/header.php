<?php

use core\classes\Store;

?>

<div class="container-fluid navegacao">
    <div class="row">
        <div class="col-6 p-3">
        <h4><?= APP_NAME; ?></h4>
        </div>
        <div class="col-6 p-3 text-end">
            <?php if(Store::adminLogado()): ?>
            <i class="fas fa-user me-2"></i><?= $_SESSION['admin_usuario']; ?>
            <i class="fas fa-sign-out-alt ms-4 me-2"></i>
            <a href="?a=admin_logout" style="text-decoration: none; color: white;">Sair</a>
            <?php endif; ?>
        </div>
    </div>
</div>
