<div>
    <div class="mb-3">
        <i class="fas fa-times me-2"></i><a href="?a=inicio">Início</a>
    </div>
    <div class="mb-3">
        <i class="fas fa-times me-2"></i><a href="?a=clientes">Clientes</a>
    </div>
    <div class="mb-3">
        <i class="fas fa-times me-2"></i><a href="?a=encomendas">Encomendas</a>
    </div>
</div>
