<div class="container">
    <div class="row my-4">
        <div class="col">
            <h3 class="text-center">Dados do cliente</h3>
            <table class="table table-borderless">
            <?php foreach($dados_cliente as $key=>$value) {?>    
                <tr>
                    <td class="text-end" width="40%"><?= $key ?></td>
                    <td width="60%"><strong><?= $value ?></strong></td>
                </tr>
            <?php } ?>
            </table>
        </div>
    </div>
</div>
