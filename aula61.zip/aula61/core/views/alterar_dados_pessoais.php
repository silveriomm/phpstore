<div class="col-6 offset-sm-3">
    <h3 class="text-center">Alterar dados</h3>
    <form action="?a=alterar_dados_pessoais_submit" method="post">
        <div class="form-group">
            <label>Email</label>
            <input type="text" max_length="200" name="text_email" value="<?= $dados_pessoais->email ?>" class="form-control form-control-sm" required>
        </div>
        <div class="form-group">
            <label>Nome</label>
            <input type="text" name="text_nome_completo" value="<?= $dados_pessoais->nome_completo ?>" max_length="100" class="form-control form-control-sm" required>
        </div>
        <div class="form-group">
            <label>Endereço</label>
            <input type="text" max_length="250" name="text_morada" value="<?= $dados_pessoais->morada ?>" class="form-control form-control-sm" required>
        </div>
        <div class="form-group">
            <label>Cidade</label>
            <input type="text" max_length="100" name="text_cidade" value="<?= $dados_pessoais->cidade ?>" class="form-control form-control-sm" required>
        </div>
        <div class="form-group">
            <label>Telefone</label>
            <input type="text" max_length="20" name="text_telefone" value="<?= $dados_pessoais->telefone ?>" class="form-control form-control-sm">
        </div>
        <div class="text-center mt-3">
            <a href="?a=perfil" class=" btn btn-danger btn-100">Cancelar</a>
            <input type="submit" value="Alterar" class=" btn btn-success btn-100">
        </div>
    </form>
    <?php if(isset($_SESSION['erro'])): ?>
        <div class="alert alert-danger my-2 text-center">
            <?= $_SESSION['erro']; ?>
            <?php unset($_SESSION['erro']); ?>
        </div>
    <?php endif; ?>
</div>
