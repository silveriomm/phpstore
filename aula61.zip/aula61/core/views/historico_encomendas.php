<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h3 class="text-center">Histórico das encomendas</h3>
            <?php if(count($historico_encomendas) == 0): ?>
                <h5 class="text-center">Não há encomendas registradas.</h5>
            <?php else: ?>
                <table</table>
            <?php endif; ?>
        </div>
    </div>
</div>
