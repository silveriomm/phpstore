<?php 
    use core\classes\Store;
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h3 class="text-center">Histórico das encomendas</h3>
            <?php if(count($historico_encomendas) == 0): ?>
                <h5 class="text-center">Não há encomendas registradas.</h5>
                <div class="text-center">
                    <a href="?a=loja" class="btn btn-primary">Ir para loja</a>
                </div>
            <?php else: ?>
                <table class="table table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Data</th>
                            <th>Cód. Encomenda</th>
                            <th>Estatus</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($historico_encomendas as $encomenda): ?>
                        <tr>
                            <td><?= $encomenda->data_encomenda ?></td>
                            <td><?= $encomenda->codigo_encomenda ?></td>
                            <td><?= $encomenda->estatus ?></td>
                            <td>
                                <a href="?a=detalhe_encomenda&id=<?= Store::aesEncriptar($encomenda->id_encomenda) ?>" class="btn btn-secondary btn-sm">Detalhes</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="row" style="background: black; color: white;">
               <p class="text-center my-1">Total de encomendas: <strong><?= count($historico_encomendas); ?></strong></p>
               </div>
            <?php endif; ?>
        </div>
    </div>
</div>
