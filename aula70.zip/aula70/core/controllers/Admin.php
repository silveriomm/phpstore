<?php 

namespace core\controllers;

use core\classes\Database;
use core\classes\EnviarEmail;
use core\classes\Store;

class Admin
{
    // ====================================================================
    public function index()
    {
        Store::layout_admin([
            'admin/layouts/html_header',
            'admin/layouts/header',
            'admin/home',
            'admin/layouts/footer',
            'admin/layouts/html_footer',
        ]);
    }
    
    // ====================================================================
    public function lista_clientes()
    {
        echo "lista de clientes";
    }
}

?>
