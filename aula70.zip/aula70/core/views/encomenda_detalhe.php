<div class="container">
    <h2 class="text-center">Detalhe da encomenda</h2>

    <!-- Dados da encomenda -->
    <div class="row">
        <div class="col">
            <div class="mb-2">
                <b>Data:</b><br> <?= $dados_encomenda->data_encomenda ?>
            </div>
            <div class="mb-2">
                <b>Endereço:</b><br> <?= $dados_encomenda->morada ?>
            </div>
            <div class="mb-2">
                <b>Cidade:</b><br> <?= $dados_encomenda->cidade ?>
            </div>
        </div>
        <div class="col">
            <div class="mb-2">
                <b>Email:</b><br> <?= $dados_encomenda->email ?>
            </div>
            <div class="mb-2">
                <b>Telefone:</b><br> <?= !empty($dados_encomenda->telefone) ? $dados_encomenda->telefone : 'Não cadastrado' ?>
            </div>
            <div class="mb-2">
              <b>Código:</b><br> <?= $dados_encomenda->codigo_encomenda ?>
            </div>
        </div>
        <div class="col align-self-center">
            <div class="mb-2 text-center">
                <h4><b>Estatus:</b><br> <?= $dados_encomenda->estatus ?></h4>
            </div>
        </div>
    </div>

    <!-- Dados da encomenda -->
    <div class="row">
        <h4 class="text-center">Produtos</h4>
        <div class="col">
            <table class="table">
                <thead>
                    <th>Descrição</th>
                    <th class="text-center">Quantidade</th>
                    <th class="text-end">Preço</th>
                </thead>
                <tbody>
                    <?php foreach($produtos_encomenda as $produto): ?>
                    <tr>
                        <td><?= $produto->designacao_produto ?></td>
                        <td class="text-center"><?= $produto->quantidade ?></td>
                        <td class="text-end"> R$ <?= number_format($produto->preco_unidade, 2, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr colspan="3" class="btn-secondary">
                        <td colspan="3" class="text-end"><b>Total: R$ <?= number_format($total_encomenda, 2, ',', '.') ?></b></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row my-3">
        <div class="col text-center">
            <a href="?a=historico_encomendas" class="btn btn-primary mb-5">Voltar</a>
        </div>
    </div>
</div>
