<?php 

// abrir a sessão
session_start();

// carrega todas as classes do admin
require_once('../../vendor/autoload.php');

// carrega o sistema de rotas
require_once('../../core/rotas_admin.php');

?>
