<?php

namespace core\controllers;

use core\classes\Store;
use core\classes\Database;
use core\models\Clientes;
use core\classes\EnviarEmail;

class Main
{
    // ====================================================
    public function index()
    {
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'inicio',
            'layouts/footer',
            'layouts/html_footer',
        ]);

    }

    // ====================================================
    public function loja()
    {
         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'loja',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
    public function novo_cliente()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }



         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'criar_cliente',
            //'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
    public function criar_cliente()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }

        // verifica se houve submit de um form
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            $this->index();
            return;
        }

        // verifica se as senhas são iguais
        if($_POST['text_senha_1'] !== $_POST['text_senha_2'])
        {
            // as senhas são diferentes
            $_SESSION['erro'] = "As senhas não são iguais.";
            $this->novo_cliente();
            return;
        }

        // verifica se existe cliente com o mesmo email
        $cliente = new Clientes();
        if($cliente->verificar_email_existe($_POST['text_email']))
        {
            $_SESSION['erro'] = "Já existe um cliente com o mesmo email.";
            $this->novo_cliente();
            return;
        }

        // Insere o novo cliente na BD
        $email_cliente = strtolower(trim($_POST['text_email']));
        $purl = $cliente->registrar_cliente();

        // envio do email para o cliente
        $email = new EnviarEmail();
        $resultado = $email->enviar_email_confirmacao_novo_cliente($email_cliente, $purl);

        if($resultado)
        {
            Store::Layout([
              'layouts/html_header',
              'layouts/header',
              'criar_cliente_sucesso',
              'layouts/footer',
              'layouts/html_footer',
            ]);
        }
        else
        {
            echo "Erro ao enviar email";
        }

    }

    // ====================================================
    public function confirmar_email()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }

        // verifica se existe um purl na query
        if(!isset($_GET['purl']))
        {
            $this->index();
            return;
        }

        $purl = $_GET['purl'];

        // verifica se o purl é válido
        if(strlen($purl) != 12)
        {
            $this->index();
            return;
        }

        $cliente = new Clientes();
        $resultado =$cliente->validar_email($purl);

        if($resultado)
        {
            Store::Layout([
              'layouts/html_header',
              'layouts/header',
              'conta_confirmada_sucesso',
              'layouts/footer',
              'layouts/html_footer',
            ]);
        }
        else
        {
            // redireciona para a página inicial
            Store::redirect('inicio');
        }

    }

    // ====================================================
    public function login()
    {
        // veirificar se já existe um cliente logado
        if(Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // apresenta o formulário de login
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'login_frm',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
    public function login_submit()
    {
      // veirificar se já existe um cliente logado
        if(Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // verifica se foi efetuado um post
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            Store::redirect();
            return;
        }

        // validar se os campos foram preenchidos
        if(
          !isset($_POST['text_usuario']) ||
          !isset($_POST['text_senha']) ||
          !filter_var(trim($_POST['text_usuario']), FILTER_VALIDATE_EMAIL)
        )
        {
          // erro de preenchimento do formulário
          $_SESSION['erro'] = 'Usuário ou senha inválidos.';
          Store::redirect('login');
          return;
        }

        // prepara os dados para o model
        $usuario = trim(strtolower($_POST['text_usuario']));
        $senha = trim($_POST['text_senha']);

        // carrega o model e verifica se o login é válido
        $cliente = new Clientes();
        $resultado = $cliente->validar_login($usuario, $senha);

        // analisa o resultado
        if(is_bool($resultado))
        {
          // login inválido
          $_SESSION['erro'] = 'Usuário ou senha inválidos.';
          Store::redirect('login');
          return;
        }
        else
        {
          // login válido
          // $_SESSION['cliente'] = $resultado
          echo '<pre>';
          print_r($resultado);
        }

    }

    // ====================================================
    public function carrinho()
    {
         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'carrinho',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

}

?>
