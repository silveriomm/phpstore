<?php

use core\classes\Store;
// $_SESSION['cliente'] = 1;
unset($_SESSION['cliente']);
?>

<div class="container-fluid navegacao">
    <div class="row">
    <div class="col-6 p-3">
        <a href="?a=inicio" class="logo">
            <h4><?=  APP_NAME ?></h4>
        </a>
    </div>
        <div class="col-6 text-end p-3">
            <a href="?a=inicio" class="nav-item">
                Início <i class="fas fa-rocket"></i>
            </a>
            <a href="?a=loja" class="nav-item">
                Loja <i class="fas fa-building"></i>
            </a>
            <!-- verifica se existe cliente na sessão -->
            <?php if(Store::clienteLogado()): ?>
                <a href="" class="nav-item">
                    Minha conta <i class="fas fa-user"></i>
                </a>
                <a href="" class="nav-item">
                    Sair <i class="fas fa-door-open"></i>
                </a>
            <?php else: ?>
                <a href="?a=login" class="nav-item">
                    Entrar <i class="fas fa-user-lock"></i>
                </a>
                <a href="?a=novo_cliente" class="nav-item">
                Criar conta <i class="fas fa-file-invoice"></i>
                </a>
            <?php endif;?>

            <a href="?a=carrinho" class="nav-item">
                Carrinho <i class="fas fa-shopping-cart"></i>
            </a>
            <span class="badge bg-warning"></span>
        </div>
    </div>
</div>
