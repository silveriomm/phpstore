<?php 

namespace core\classes;

class Store
{
    public function teste()
    {
        echo " Olá";
    }   
}

?>
