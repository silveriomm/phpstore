<?php

namespace core\controllers;

use core\classes\Store;
use core\classes\Database;
use core\models\Clientes;
use core\classes\EnviarEmail;
use core\models\Produtos;
use core\models\Encomendas;

class Main
{
    // ====================================================
    public function index()
    {
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'inicio',
            'layouts/footer',
            'layouts/html_footer',
        ]);

    }

    // ====================================================
    public function loja()
    {
        // buscar a lista de produtos
        $produtos = new Produtos();

        // analisa que categoria buscar
        $c = 'todos';

        if(isset($_GET['c']))
        {
          $c = $_GET['c'];
        }

        $lista_produtos = $produtos->lista_produtos_disponiveis($c);
        $lista_categorias = $produtos->lista_categorias();

        $dados = [
          'produtos' => $lista_produtos,
          'categorias' => $lista_categorias
        ];

         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'loja',
            'layouts/footer',
            'layouts/html_footer',
        ], $dados);
    }

    // ====================================================
    public function novo_cliente()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }



         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'criar_cliente',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
    public function criar_cliente()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }

        // verifica se houve submit de um form
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            $this->index();
            return;
        }

        // verifica se as senhas são iguais
        if($_POST['text_senha_1'] !== $_POST['text_senha_2'])
        {
            // as senhas são diferentes
            $_SESSION['erro'] = "As senhas não são iguais.";
            $this->novo_cliente();
            return;
        }

        // verifica se existe cliente com o mesmo email
        $cliente = new Clientes();
        if($cliente->verificar_email_existe($_POST['text_email']))
        {
            $_SESSION['erro'] = "Já existe um cliente com o mesmo email.";
            $this->novo_cliente();
            return;
        }

        // Insere o novo cliente na BD
        $email_cliente = strtolower(trim($_POST['text_email']));
        $purl = $cliente->registrar_cliente();

        // envio do email para o cliente
        $email = new EnviarEmail();
        $resultado = $email->enviar_email_confirmacao_novo_cliente($email_cliente, $purl);

        if($resultado)
        {
            Store::Layout([
              'layouts/html_header',
              'layouts/header',
              'criar_cliente_sucesso',
              'layouts/footer',
              'layouts/html_footer',
            ]);
        }
        else
        {
            echo "Erro ao enviar email";
        }

    }

    // ====================================================
    public function confirmar_email()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }

        // verifica se existe um purl na query
        if(!isset($_GET['purl']))
        {
            $this->index();
            return;
        }

        $purl = $_GET['purl'];

        // verifica se o purl é válido
        if(strlen($purl) != 12)
        {
            $this->index();
            return;
        }

        $cliente = new Clientes();
        $resultado =$cliente->validar_email($purl);

        if($resultado)
        {
            Store::Layout([
              'layouts/html_header',
              'layouts/header',
              'conta_confirmada_sucesso',
              'layouts/footer',
              'layouts/html_footer',
            ]);
        }
        else
        {
            // redireciona para a página inicial
            Store::redirect('inicio');
        }

    }

    // ====================================================
    public function login()
    {
        // veirificar se já existe um cliente logado
        if(Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // apresenta o formulário de login
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'login_frm',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
    public function login_submit()
    {
      // veirificar se já existe um cliente logado
        if(Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // verifica se foi efetuado um post
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            Store::redirect();
            return;
        }

        // validar se os campos foram preenchidos
        if(
          !isset($_POST['text_usuario']) ||
          !isset($_POST['text_senha']) ||
          !filter_var(trim($_POST['text_usuario']), FILTER_VALIDATE_EMAIL)
        )
        {
          // erro de preenchimento do formulário
          $_SESSION['erro'] = 'Usuário ou senha inválidos.';
          Store::redirect('login');
          return;
        }

        // prepara os dados para o model
        $usuario = trim(strtolower($_POST['text_usuario']));
        $senha = trim($_POST['text_senha']);

        // carrega o model e verifica se o login é válido
        $cliente = new Clientes();
        $resultado = $cliente->validar_login($usuario, $senha);

        // analisa o resultado
        if(is_bool($resultado))
        {
          // login inválido
          $_SESSION['erro'] = 'Usuário ou senha inválidos.';
          Store::redirect('login');
          return;
        }
        else
        {
          // login válido
          $_SESSION['cliente'] = $resultado->id_cliente;
          $_SESSION['usuario'] = $resultado->email;
          $_SESSION['nome_cliente'] = $resultado->nome_completo;

          // redireciona para o local correto
          if(isset($_SESSION['tmp_carrinho']))
          {
            unset($_SESSION['tmp_carrinho']);
            // redireciona para o resumo da encomenda
            Store::redirect('finalizar_encomenda_resumo');
          }
          else 
          {
            // redireciona para a loja
            Store::redirect();
          }
        }

    }

    // ====================================================
    public function logout()
    {
        // remove o cliente da sessão
        unset($_SESSION['cliente']);
        unset($_SESSION['usuario']);
        unset($_SESSION['nome_cliente']);

        // redireciona para o inicio
        Store::redirect();
    }

    // ====================================================
    public function perfil()
    {
        // verifica se já existe um utilizador logado
        if(!Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // buscar informações do cliente
        $cliente = new Clientes();
        
        $dtemp = $cliente->buscar_dados_cliente($_SESSION['cliente']);

        $dados_cliente = [
            'Email' => $dtemp->email,
            'Nome' => $dtemp->nome_completo,
            'Endereço' => $dtemp->morada,
            'Cidade' => $dtemp->cidade,
            'Telefone' => $dtemp->telefone,
        ];

        $dados = [
            'dados_cliente' => $dados_cliente
        ];

        // apresenta o formulário de perfil
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'perfil_navegacao',
            'perfil',
            'layouts/footer',
            'layouts/html_footer',
        ], $dados);
    }

    // ====================================================
    public function alterar_dados_pessoais()
    {
        // verifica se existe um utilizador logado
        if(!Store::clienteLogado())
        {
            Store::redirect();
            return;
        }


        $cliente = new Clientes();
        $dados = [
            'dados_pessoais' => $cliente->buscar_dados_cliente($_SESSION['cliente'])
        ];

        // apresenta o formulário de perfil
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'perfil_navegacao',
            'alterar_dados_pessoais',
            'layouts/footer',
            'layouts/html_footer',
        ], $dados);
    }

    // ====================================================
    public function alterar_dados_pessoais_submit()
    {
        // verifica se existe um utilizador logado
        if(!Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // verifica se é um submit
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            Store::redirect();
            return;
        }

        // validar dados
        $email = trim(strtolower($_POST['text_email']));
        $nome = trim($_POST['text_nome_completo']);
        $morada = trim($_POST['text_morada']);
        $cidade = trim($_POST['text_cidade']);
        $telefone = trim($_POST['text_telefone']);

        // verifica se o email é válido
        if(!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $_SESSION['erro'] = "Email inválido.";
            $this->alterar_dados_pessoais();
            return;
        }

        // validar campos
        if(empty($nome) ||
            empty($morada) ||
                empty($cidade))
        {
            $_SESSION['erro'] = "Preencha corretamento o formulário.";
            $this->alterar_dados_pessoais();
            return;
        }

        // validar se o email já existe
        $cliente = new Clientes();
        $existe_noutra_conta = $cliente->verificar_se_email_existe_noutra_conta($_SESSION['cliente'], $email);

        if($existe_noutra_conta)
        {
            $_SESSION['erro'] = "Já existe um usuário com este email.";
            $this->alterar_dados_pessoais();
            return;
        }

        // atualizar os dados do cliente
        $cliente->atualizar_dados_cliente($email, $nome, $morada, $cidade, $telefone);
        
        // atualizar os dados na sessão
        $_SESSION['usuario'] = $email;
        $_SESSION['nome_cliente'] = $nome;

        Store::redirect('perfil');
    }
    
    // ====================================================
    public function alterar_password()
    {
        // verifica se existe um utilizador logado
        if(!Store::clienteLogado())
        {
            Store::redirect();
            return;
        }


        // apresenta o formulário de alterar senha
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'perfil_navegacao',
            'alterar_password',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
    public function alterar_password_submit()
    {
        // verifica se existe um utilizador logado
        if(!Store::clienteLogado())
        {
            Store::redirect();
            return;
        }

        // verifica se é um submit
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            Store::redirect();
            return;
        }

        // validar dados
        $senha_atual = trim($_POST['text_senha_atual']);
        $nova_senha = trim($_POST['text_nova_senha']);
        $repetir_nova_senha = trim($_POST['text_repetir_nova_senha']);
        
        // validar se nova senha não é vazia
        if(strlen($nova_senha) < 3)
        {
            $_SESSION['erro'] = "A nova senha não pode ser vazia ou conter menos de 3 carcteres.";
            $this->alterar_password();
            return;
        }

        // verifica se as senhas estão iguais
        if($nova_senha != $repetir_nova_senha)
        {
            $_SESSION['erro'] = "As novas senhas não são iguais.";
            $this->alterar_password();
            return;
        }
        
        // verifica se a senha atual está correta
        $cliente = new Clientes();
        if(!$cliente->ver_se_senha_esta_correta($_SESSION['cliente'], $senha_atual))
        {
            $_SESSION['erro'] = "Senha atual inválida.";
            $this->alterar_password();
            return;
        }

        // verifica se a senha atual é diferente da nova senha
        if($senha_atual == $nova_senha)
        {
            $_SESSION['erro'] = "A nova senha é igual a senha atual.";
            $this->alterar_password();
            return;
        }

        // atualizar a nova senha
        $cliente->atualizar_a_nova_senha($_SESSION['cliente'], $nova_senha);
        
        // redireciona para o perfil
        Store::redirect('perfil');
        return;

    }

    // ====================================================
    public function historico_encomendas()
    {
        if(!Store::clienteLogado())
        {
            Store::redirect('perfil');
            return;
        }

        // carrega o histórico das encomendas
        $encomendas = new Encomendas();
        $historico_encomendas = $encomendas->buscar_historico_encomendas($_SESSION['cliente']);

        // Store::printData($historico_encomendas);

        $dados = [
            'historico_encomendas' => $historico_encomendas
        ];

        // apresenta a view com os dados
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'perfil_navegacao',
            'historico_encomendas',
            'layouts/footer',
            'layouts/html_footer',
        ], $dados);
    }
    
    // ====================================================
    public function historico_encomendas_detalhe()
    {
        if(!Store::clienteLogado())
        {
            Store::redirect('perfil');
            return;
        }

        // verifica se veio um id encriptado
        if(!isset($_GET['id']))
        {
            Store::redirect();
            return;
        }

        $id_encomenda = null;

        // verifica se é um string com 32 caracteres
        if(strlen($_GET['id']) != 32)
        {
            Store::redirect();
            return;
        }
        else
        {
            $id_encomenda = Store::aesDesencriptar($_GET['id']);
            if(empty($id_encomenda))
            {
                Store::redirect();
                return;
            }
        }

        // verifica se a encomenda pertence ao cliente
        $encomendas = new Encomendas();
        $resultado = $encomendas->verificar_encomenda_cliente($_SESSION['cliente'], $id_encomenda);

        if(!$resultado)
        {
            Store::redirect();
            return;
        }
         
        // buscar detalhes da encomenda
        $detalhe_encomenda = $encomendas->detalhe_de_encomenda($_SESSION['cliente'], $id_encomenda);

        // calcular o valor total da encomenda
        $total = 0;
        foreach($detalhe_encomenda['produtos_encomenda'] as $produto)
        {
            $total += ($produto->quantidade * $produto->preco_unidade);
        }       

        $dados = [
            'dados_encomenda' => $detalhe_encomenda['dados_encomenda'],
            'produtos_encomenda' => $detalhe_encomenda['produtos_encomenda'],
            'total_encomenda' => $total
        ];

        // apresenta a view com os detalhes
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'perfil_navegacao',
            'encomenda_detalhe',
            'layouts/footer',
            'layouts/html_footer',
        ], $dados);
    }

    // ====================================================
    public function pagamento()
    {
        // simulação do webbook de getway de pagamento
        
        // verifica o codigo da encomenda
        $codigo_encomenda = '';
        if(!isset($_GET['cod']))
        {
            return;
        }
        else 
        {
            $codigo_encomenda = $_GET['cod'];
        }

        // verifica se existe o codigo ativo
        $encomenda = new Encomendas();

        $resultado = $encomenda->efetuar_pagamento($codigo_encomenda);

        echo (int)$resultado;
    }
}

?>
