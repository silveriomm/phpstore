<div class="container espaco-fundo">
    <div class="row">
        <div class="col-12 text-center my-4">
            <a class="btn btn-primary btn-sm" href="?a=loja&c=todos">Todos</a>
            <a class="btn btn-primary btn-sm" href="?a=loja&c=homem">Homem</a>
            <a class="btn btn-primary btn-sm" href="?a=loja&c=mulher">Mulher</a>
        </div>
    </div>
    <div class="row">
        <?php foreach($produtos as $produto): ?>
        <div class="col-sm-4 col-6 p-2">
            <div class="text-center p-3 box-produto">
                <img class="img-fluid" src="assets/images/produtos/<?= $produto->imagem ?>">
                <h4><?= $produto->nome_produto ?></h4>
                <h2><?= $produto->preco ?></h2>
                <div>
                    <button class="btn btn-primary btn-sm">Adicionar ao carrinho</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
