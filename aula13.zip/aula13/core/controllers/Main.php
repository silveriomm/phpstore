<?php 

namespace core\controllers;

use core\classes\Store;
use core\classes\Database;

class Main
{
    // ====================================================
    public function index()
    {
        Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'inicio',
            'layouts/footer',
            'layouts/html_footer',    
        ]);

    }

    // ====================================================
    public function loja()
    {
         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'loja',
            'layouts/footer',
            'layouts/html_footer',    
        ]);
    }
    
    // ====================================================
    public function novo_cliente()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }



         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'criar_cliente',
            //'layouts/footer',
            'layouts/html_footer',    
        ]);
    }
    
    // ====================================================
    public function criar_cliente()
    {
        // verifica se já existe sessão
        if(Store::clienteLogado())
        {
            $this->index();
            return;
        }

        // verifica se houve submit de um form
        if($_SERVER['REQUEST_METHOD'] != 'POST')
        {
            $this->index();
            return;
        }

        // verifica se as senhas são iguais
        if($_POST['text_senha_1'] !== $_POST['text_senha_2'])
        {
            // as senhas são diferentes
            $_SESSION['erro'] = "As senhas não são iguais.";
            $this->novo_cliente();
            return;
        }

        // verifica se existe cliente com o mesmo email
        $bd = new Database();
        $parametros = [
            ':email' => strtolower(trim($_POST['text_email']))
        ];
        $resultados = $bd->select("SELECT email FROM clientes WHERE email = :email", $parametros);

        // se o cliente já existe
        if(count($resultados) != 0)
        {
            $_SESSION['erro'] = "Já existe um cliente com este email";
            $this->novo_cliente();
            return;
        }

        die('Ok');

    }
    
    // ====================================================
    public function carrinho()
    {
         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'carrinho',
            'layouts/footer',
            'layouts/html_footer',    
        ]);
    }

}

?>
