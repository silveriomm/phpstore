<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h1>Carrinho</h1>
            <a href="?a=limpar_carrinho" class="btn btn-sm btn-info">Limpar carrinho</a>
            <pre>
            <?php print_r($_SESSION); ?>
            </pre>
        </div>
    </div>
</div>
