<?php

namespace core\controllers;

use core\classes\Store;
use core\classes\EnviarEmail;
use core\classes\Database;
use core\modes\Produtos;


class Carrinho
{

    // ====================================================
    public function adicionar_carrinho()
    {
      // busca o id do produto
      if(!isset($_GET['id_produto']))
      {
        header("Location: ". BASE_URL . "index.php?a=loja");
        return;
      }

      // define o id do produto
      $id_produto = $_GET['id_produto'];

      $produtos = new Produtos;
      $resultados = $produtos->verificar_stock_produtos($id_produto);

      if(!$resultados)
      {
        header("Location: " . BASE_URL . "index.php?a=loja");
        return;
      }

      // adiciona a variável a sessão
      $carrinho = [];

      if(isset($_SESSION['carrinho']))
      {
        $carrinho = $_SESSION['carrinho'];
      }

      // adiciona o produto ao carrinho
      if(key_exists($id_produto, $carrinho))
      {
        // já existe o produto, acrescenta mais
        $carrinho[$id_produto] ++;
      }
      else
      {
        // adiciona novo produto
        $carrinho[$id_produto] = 1;
      }

      $_SESSION['carrinho'] = $carrinho;

      $total_produtos = 0;

      foreach($carrinho as $quantidade)
      {
        $total_produtos += $quantidade;
      }

      echo $total_produtos;
    }

    // ====================================================
    public function limpar_carrinho()
    {
      // limpa o carrinho de todos os produtos
      unset($_SESSION['carrinho']);

      // reinicia a página do carrinho
      $this->carrinho();
    }

    // ====================================================
    public function carrinho()
    {
         Store::Layout([
            'layouts/html_header',
            'layouts/header',
            'carrinho',
            'layouts/footer',
            'layouts/html_footer',
        ]);
    }

    // ====================================================
}
?>
