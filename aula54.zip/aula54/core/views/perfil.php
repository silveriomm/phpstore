<div>
    <?php 
        echo '<pre>';
        print_r($dados_cliente);
    ?>
</div>
